package com.example.myapplication

import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import java.util.*

class ClientInfo : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_client_info)


        //SET SUBMIT BUTTON
        val tvSubmittedInfo = findViewById<TextView>(R.id.btn_submit)
        tvSubmittedInfo.setOnClickListener{
            val full_name = findViewById<EditText>(R.id.etFirstName).text.toString()
            val height_ft = findViewById<EditText>(R.id.etHeightFt).text.toString().toInt()
            val height_in = findViewById<EditText>(R.id.etHeightIn).text.toString().toInt()
            val start_weight = findViewById<EditText>(R.id.etStartWeight).text.toString().toDouble()
            val goal_weight = findViewById<EditText>(R.id.etWeightGoal).text.toString().toDouble()

            //validate input for height in feet
            if (height_ft < 3 || height_ft > 8) {
                Toast.makeText(this, "Please enter a valid height in feets.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            //validate input for height in inches
            if (height_in < 0 || height_in > 11) {
                Toast.makeText(this, "Please enter a valid height in inches.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            //validate input for weight
            if (start_weight < 50.0 || start_weight > 300.0 || goal_weight < 50.0 || goal_weight > 300.0) {
                Toast.makeText(this, "Please enter a valid weight.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            Intent(this, SubmittedInfo::class.java).also{
                it.putExtra("EXTRA_FLNAME", full_name)
                it.putExtra("EXTRA_HEIGHTFT", height_ft)
                it.putExtra("EXTRA_HEIGHTIN", height_in)
                it.putExtra("EXTRA_STWEIGHT", start_weight)
                it.putExtra("EXTRA_GLWEIGHT", goal_weight)
                startActivity(it)
            }

        }

        //SET BACK BUTTON TO GO HOME
       val btnBack = findViewById<Button>(R.id.back_btn_client_info)
       btnBack.setOnClickListener{
           finish()
       }

    }
}