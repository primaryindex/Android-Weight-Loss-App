package com.example.myapplication

import android.os.Bundle
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.internal.ViewUtils.hideKeyboard
import org.w3c.dom.Text
import java.util.*

class SubmittedInfo : AppCompatActivity() {
    //empty input when done
    var isNewOp = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_submitted_info)

        //init variables from ClientInfo
        val full_name = intent.getStringExtra ("EXTRA_FLNAME")
        val city = intent.getStringExtra("EXTRA_CITY")
        val state = intent.getStringExtra("EXTRA_STATE")
        val height_ft = intent.getIntExtra("EXTRA_HEIGHTFT", 0)
        val height_in = intent.getIntExtra("EXTRA_HEIGHTIN", 0)
        val start_weight = intent.getDoubleExtra("EXTRA_STWEIGHT", 0.0)
        val goal_weight = intent.getDoubleExtra("EXTRA_GLWEIGHT", 0.0)

        //DISPLAY CLIENT INFO
        val clientInfo = "Hello $full_name, your current weight is $start_weight"
        val tvSubmittedInfo = findViewById<TextView>(R.id.tvIntroHeadline)
        tvSubmittedInfo.text = clientInfo

        //Date you reach your goal
        val tvEndDateGoal = findViewById<TextView>(R.id.tvEndDateGoal)
        tvEndDateGoal.text = updateGoalDays(start_weight, goal_weight )


        //Calculate BMI and print it out to TV
        val bmi = calculateBMI(start_weight, height_ft, height_in)


        //UPDATE WEIGHT
        val tvUpdateWeight = findViewById<TextView>(R.id.btn_update_weight)
        tvUpdateWeight.setOnClickListener {
            val currentWeightText = findViewById<EditText>(R.id.etUpdateWeight).text.toString()

            //tests if TextView is empty
            if (currentWeightText.isNotBlank()) {
                val currentWeight = currentWeightText.toDouble()
                val clientInfo = "Hello $full_name, your current weight is $currentWeight"
                tvSubmittedInfo.text = clientInfo

                //update progress bar
                val progressBar = findViewById<ProgressBar>(R.id.progressBar)
                val progress = ((currentWeight - start_weight) / (goal_weight - start_weight) * 100).toInt()
                progressBar.progress = progress

                //Calculate BMI and print it out into TV
                val bmi = calculateBMI(currentWeight, height_ft, height_in)
                tvEndDateGoal.text = updateGoalDays(currentWeight, goal_weight )

                //toast to keep moral up if weight is still not met
                if(currentWeight != goal_weight){
                    //takes string array from string.xml
                    val messages = resources. getStringArray(R.array.congratulations)
                    val random = Random()
                    val index = random.nextInt(messages.size)
                    val message = messages[index]
                    Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                }else{
                    //congratulate if weight goal is met
                    congratulationToast(currentWeight, goal_weight)
                }
                // Clear the text after getting input
                findViewById<EditText>(R.id.etUpdateWeight).setText("")
            } else {
                Toast.makeText(this, "Please enter your current weight", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun calculateBMI(weight: Double, height_ft: Int, height_in: Int) {
        val heightToInches = (height_ft * 12) + height_in
        val heightInM = heightToInches * 0.0254 //convert measurements to meters
        val weightToKg = weight * 0.453592 //convert weight to kg
        val bmi = weightToKg / (heightInM * heightInM)
        val formattedBMI = String.format("%.1f", bmi) //two dec after .
        val clientBMI = "Your BMI: $formattedBMI"
        val tvBMI = findViewById<TextView>(R.id.tvBMI)
        tvBMI.text = clientBMI
    }

    private fun daysWeightLose(startWeight: Double, endWeight: Double): Double {
        val rate = 0.2 // pounds per day
        var currentWeight = startWeight
        var lbsToLose = startWeight - endWeight
        var days = 0.0
        while (lbsToLose > 0) {
            lbsToLose -= rate
            days++
        }
        return days
    }

    private fun updateGoalDays (currentWeight: Double, goalWeight: Double): String {
        val daysUntilWeightGoal = daysWeightLose(currentWeight, goalWeight)
        val stringDaysUntilWeightGoal = "In $daysUntilWeightGoal days, you will reach your goal"
        return stringDaysUntilWeightGoal
    }


    private fun congratulationToast(startWeight: Double, goalWeight: Double){
        if (startWeight == goalWeight){
            Toast.makeText(this, "Congratulations!!!", Toast.LENGTH_SHORT).show()
        }
    }
}